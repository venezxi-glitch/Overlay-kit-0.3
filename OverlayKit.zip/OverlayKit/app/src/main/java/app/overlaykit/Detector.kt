package app.overlaykit

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

// Size values are fractions of the image height. Colors and sizes were measured on three
// 2400x1080 screenshots (Showdown and a bounty-style mode): enemy bar body 233,22,47, about 96x14 px;
// own bar body 72,227,53. They must be rechecked on other modes and phones.
data class DetectorConfig(
    // Enemy bar body color range (exact, so red HUD parts and crates do not match).
    val redRMin: Int = 212, val redRMax: Int = 250,
    val redGMin: Int = 8, val redGMax: Int = 56,
    val redBMin: Int = 28, val redBMax: Int = 80,
    // Own bar body color range.
    val grnRMin: Int = 45, val grnRMax: Int = 95,
    val grnGMin: Int = 185, val grnGMax: Int = 245,
    val grnBMin: Int = 35, val grnBMax: Int = 75,
    // Soft red, used only for the ground circle under destructible boxes.
    val softMin: Int = 170, val softG: Int = 58, val softB: Int = 62,
    val minW: Float = 0.02f, val maxW: Float = 0.14f,
    val minH: Float = 0.004f, val maxH: Float = 0.026f,
    val minAspect: Float = 2.6f, val maxAspect: Float = 30f,
    val minFill: Float = 0.40f,
    val discMax: Float = 0.06f,
    val tintMax: Float = 0.40f,
    val fullBarW: Float = 0.089f,
    val unitCenter: Float = 0.8f,
    val roiTop: Float = 0.05f, val roiBottom: Float = 0.98f,
    val boxWidthMul: Float = 1.2f, val boxHeightMul: Float = 1.5f, val boxGap: Float = 1f,
)

class Bar(
    val x0: Int, val x1: Int, val y0: Int, val y1: Int,
    val cx: Float, val hp: Float, val disc: Float,
)

class Target(
    val l: Float, val t: Float, val r: Float, val b: Float,
    val dist: Float, val hp: Float,
)

class Analysis(
    val enemies: List<Bar>,
    val own: Bar?,
    val redBars: Int,
    val boxesSkipped: Int,
    val greenBars: Int,
    val tinted: Boolean,
    val softRedPct: Float,
)

private class Runs {
    var y = IntArray(256)
    var x0 = IntArray(256)
    var x1 = IntArray(256)
    var parent = IntArray(256)
    var n = 0

    fun add(yy: Int, s: Int, e: Int) {
        if (n == y.size) {
            val m = y.size * 2
            y = y.copyOf(m); x0 = x0.copyOf(m); x1 = x1.copyOf(m); parent = parent.copyOf(m)
        }
        y[n] = yy; x0[n] = s; x1[n] = e; parent[n] = n
        n++
    }

    fun find(a: Int): Int {
        var r = a
        while (parent[r] != r) {
            parent[r] = parent[parent[r]]
            r = parent[r]
        }
        return r
    }

    fun union(a: Int, b: Int) {
        val ra = find(a)
        val rb = find(b)
        if (ra != rb) parent[rb] = ra
    }
}

private class Blob(val x0: Int, val x1: Int, val y0: Int, val y1: Int)

object Detector {
    private const val MAX_RUNS = 20000
    private const val KIND_RED = 0
    private const val KIND_GREEN = 1

    private fun matches(p: Int, kind: Int, c: DetectorConfig): Boolean {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        return if (kind == KIND_RED) {
            r in c.redRMin..c.redRMax && g in c.redGMin..c.redGMax && b in c.redBMin..c.redBMax
        } else {
            r in c.grnRMin..c.grnRMax && g in c.grnGMin..c.grnGMax && b in c.grnBMin..c.grnBMax
        }
    }

    private fun isSoftRed(p: Int, c: DetectorConfig): Boolean {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        return r >= c.softMin && g * 100 <= r * c.softG && b * 100 <= r * c.softB
    }

    /** Share of soft-red pixels on a sparse grid; a high value means the whole screen is tinted. */
    private fun softRedFraction(px: IntArray, w: Int, h: Int, c: DetectorConfig): Float {
        var hit = 0
        var total = 0
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                if (isSoftRed(px[y * w + x], c)) hit++
                total++
                x += 5
            }
            y += 5
        }
        return if (total == 0) 0f else hit.toFloat() / total
    }

    private fun findBars(px: IntArray, w: Int, h: Int, c: DetectorConfig, kind: Int): List<Blob> {
        val yStart = (h * c.roiTop).toInt().coerceIn(0, h)
        val yEnd = (h * c.roiBottom).toInt().coerceIn(yStart, h)
        val runs = Runs()
        var prevStart = 0
        var prevEnd = 0
        for (y in yStart until yEnd) {
            val curStart = runs.n
            val row = y * w
            var x = 0
            while (x < w) {
                if (!matches(px[row + x], kind, c)) { x++; continue }
                val s = x
                while (x < w && matches(px[row + x], kind, c)) x++
                if (runs.n >= MAX_RUNS) break
                runs.add(y, s, x - 1)
            }
            val curEnd = runs.n
            var i = prevStart
            var j = curStart
            while (i < prevEnd && j < curEnd) {
                if (runs.x0[i] <= runs.x1[j] && runs.x0[j] <= runs.x1[i]) runs.union(i, j)
                if (runs.x1[i] < runs.x1[j]) i++ else j++
            }
            prevStart = curStart
            prevEnd = curEnd
            if (runs.n >= MAX_RUNS) break
        }

        val n = runs.n
        val minX = IntArray(n) { Int.MAX_VALUE }
        val maxX = IntArray(n) { -1 }
        val minY = IntArray(n) { Int.MAX_VALUE }
        val maxY = IntArray(n) { -1 }
        val cnt = IntArray(n)
        for (i in 0 until n) {
            val r = runs.find(i)
            minX[r] = min(minX[r], runs.x0[i])
            maxX[r] = max(maxX[r], runs.x1[i])
            minY[r] = min(minY[r], runs.y[i])
            maxY[r] = max(maxY[r], runs.y[i])
            cnt[r] += runs.x1[i] - runs.x0[i] + 1
        }

        val out = ArrayList<Blob>()
        for (r in 0 until n) {
            if (cnt[r] == 0) continue
            val bw = maxX[r] - minX[r] + 1
            val bh = maxY[r] - minY[r] + 1
            if (bw < c.minW * h || bw > c.maxW * h) continue
            if (bh < c.minH * h || bh > c.maxH * h) continue
            val aspect = bw.toFloat() / bh
            if (aspect < c.minAspect || aspect > c.maxAspect) continue
            if (cnt[r].toFloat() / (bw * bh) < c.minFill) continue
            out.add(Blob(minX[r], maxX[r], minY[r], maxY[r]))
        }
        return out
    }

    private fun discScore(px: IntArray, w: Int, h: Int, c: DetectorConfig, cx: Float, bottom: Int, bw: Float): Float {
        val x0 = max(0, (cx - 0.65f * bw).toInt())
        val x1 = min(w, (cx + 0.65f * bw).toInt())
        val y0 = min(h, (bottom + 0.35f * bw).toInt())
        val y1 = min(h, (bottom + 1.75f * bw).toInt())
        if (x1 <= x0 || y1 <= y0) return 0f
        var red = 0
        for (y in y0 until y1) {
            val row = y * w
            for (x in x0 until x1) if (isSoftRed(px[row + x], c)) red++
        }
        return red.toFloat() / ((x1 - x0) * (y1 - y0))
    }

    /**
     * px is packed 0x00RRGGBB, size w*h, landscape (h is the short side).
     * Enemies: bars in the exact enemy bar color, minus those standing on the red ground circle
     * of a destructible box. Own: the green bar nearest to the hint position.
     */
    fun analyze(px: IntArray, w: Int, h: Int, c: DetectorConfig, hintX: Float, hintY: Float): Analysis {
        if (w <= 0 || h <= 0 || px.size < w * h) return Analysis(emptyList(), null, 0, 0, 0, false, 0f)
        val soft = softRedFraction(px, w, h, c)
        // On a tinted screen (for example while dead) the ground circle test cannot work.
        val tinted = soft >= c.tintMax
        val fullW = c.fullBarW * h

        fun centerX(b: Blob): Float =
            if ((b.x1 - b.x0 + 1) < 0.9f * fullW) b.x0 + fullW / 2f else (b.x0 + b.x1 + 1) / 2f

        val enemies = ArrayList<Bar>()
        var skipped = 0
        val reds = findBars(px, w, h, c, KIND_RED)
        for (b in reds) {
            val cx = centerX(b)
            val bw = b.x1 - b.x0 + 1
            val disc = if (tinted) 0f else discScore(px, w, h, c, cx, b.y1, max(bw.toFloat(), fullW))
            if (disc > c.discMax) { skipped++; continue }
            enemies.add(Bar(b.x0, b.x1, b.y0, b.y1, cx, min(1f, bw / fullW), disc))
        }

        val greens = findBars(px, w, h, c, KIND_GREEN)
        val aspect = w.toFloat() / h
        var own: Bar? = null
        var bestD = Float.MAX_VALUE
        for (b in greens) {
            val cx = centerX(b)
            val bw = b.x1 - b.x0 + 1
            val d = hypot(((cx / w) - hintX) * aspect, ((b.y1 + c.unitCenter * fullW) / h) - hintY)
            if (d < bestD) {
                bestD = d
                own = Bar(b.x0, b.x1, b.y0, b.y1, cx, min(1f, bw / fullW), 0f)
            }
        }
        return Analysis(enemies, own, reds.size, skipped, greens.size, tinted, soft)
    }

    fun distance(l: Float, t: Float, r: Float, b: Float, aspect: Float, ownX: Float, ownY: Float): Float {
        val dx = ((l + r) / 2f - ownX) * aspect
        val dy = (t + b) / 2f - ownY
        return hypot(dx, dy)
    }

    /** Boxes are placed below each bar. Distance is in screen heights. Sorted nearest first. */
    fun buildTargets(bars: List<Bar>, w: Int, h: Int, c: DetectorConfig, ownX: Float, ownY: Float): List<Target> {
        val aspect = w.toFloat() / h
        val fullW = c.fullBarW * h
        val boxW = fullW * c.boxWidthMul
        val boxH = fullW * c.boxHeightMul
        return bars.map { bar ->
            val top = bar.y1 + 1f + c.boxGap
            val l = (bar.cx - boxW / 2f) / w
            val r = (bar.cx + boxW / 2f) / w
            val t = top / h
            val b = (top + boxH) / h
            Target(l, t, r, b, distance(l, t, r, b, aspect, ownX, ownY), bar.hp)
        }.sortedBy { it.dist }
    }
}
