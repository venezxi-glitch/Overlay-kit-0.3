package app.overlaykit

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
        private const val TAG = "OverlayKit"
        private const val CHANNEL = "capture"
        private const val NOTIF_ID = 1
        private const val FRAME_INTERVAL_MS = 66L
        private const val TARGET_HEIGHT = 540
        private const val VERSION = "0.3"
    }

    private val thread = HandlerThread("capture").apply { start() }
    private val handler = Handler(thread.looper)
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var menu: MenuController? = null
    private val tracker = Tracker()
    private val own = OwnTracker()

    private var capW = 0
    private var capH = 0
    private var lastFrame = 0L
    private var lastStats = 0L
    private var lastThumb = 0L
    private var frames = 0L
    private var fpsStart = 0L
    private var fpsCount = 0
    private var fps = 0f
    private var procMs = 0f
    private var lastError = ""
    private var px = IntArray(0)
    private var started = false
    private var released = false

    @Volatile private var saveRequested = false
    @Volatile private var lastReport = "No frame processed yet."

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (started) return START_NOT_STICKY

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        started = true
        Config.load(this)
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val ov = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(ov, lp)
        overlay = ov

        val m = MenuController(
            this, wm,
            onChanged = { Config.save(this) },
            onStop = { stopSelf() },
            onCopy = { copyReport() },
            onSave = { saveRequested = true; menu?.setNote("Saving next frame...") },
        )
        m.show()
        menu = m

        startCapture()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Overlay Kit", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Overlay Kit is running")
            .setContentText("Tap to stop")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    /**
     * The virtual display is created once, already in landscape size, and never resized.
     * Resizing it after the game rotated the screen produced a squeezed, mostly black picture.
     */
    private fun startCapture() {
        val p = projection ?: return
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        val w = max(dm.widthPixels, dm.heightPixels)
        val h = min(dm.widthPixels, dm.heightPixels)
        if (w <= 0 || h <= 0) { lastError = "display size is 0"; return }
        capW = w
        capH = h
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ onFrame(it) }, handler)
        reader = r
        display = p.createVirtualDisplay(
            "overlaykit", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
    }

    private fun onFrame(r: ImageReader) {
        val img: Image? = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            lastError = "acquire: ${e.javaClass.simpleName}"
            null
        }
        if (img == null) return
        try {
            frames++
            val now = SystemClock.uptimeMillis()
            if (now - lastFrame < FRAME_INTERVAL_MS) return
            lastFrame = now
            val t0 = System.nanoTime()

            val plane = img.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            val shortSide = min(img.width, img.height)
            val step = max(1, (shortSide / TARGET_HEIGHT.toFloat()).roundToInt())
            val ow = img.width / step
            val oh = img.height / step
            if (ow <= 0 || oh <= 0) return
            if (px.size != ow * oh) px = IntArray(ow * oh)

            var lumaSum = 0L
            var samples = 0
            var nonBlack = 0
            var bx0 = Int.MAX_VALUE
            var bx1 = -1
            var by0 = Int.MAX_VALUE
            var by1 = -1
            for (y in 0 until oh) {
                val rowOff = y * step * rowStride
                for (x in 0 until ow) {
                    val o = rowOff + x * step * pixelStride
                    val rr = buf.get(o).toInt() and 255
                    val gg = buf.get(o + 1).toInt() and 255
                    val bb = buf.get(o + 2).toInt() and 255
                    px[y * ow + x] = (rr shl 16) or (gg shl 8) or bb
                    if ((x and 3) == 0 && (y and 3) == 0) {
                        samples++
                        val l = rr + gg + bb
                        lumaSum += l
                        if (l > 36) {
                            nonBlack++
                            if (x < bx0) bx0 = x
                            if (x > bx1) bx1 = x
                            if (y < by0) by0 = y
                            if (y > by1) by1 = y
                        }
                    }
                }
            }
            val bright = if (samples > 0) (lumaSum / (samples * 3L)).toInt() else 0
            val nonBlackPct = if (samples > 0) nonBlack * 100f / samples else 0f
            val boxW = if (nonBlack > 0) (bx1 - bx0 + 1f) / ow else 0f
            val boxH = if (nonBlack > 0) (by1 - by0 + 1f) / oh else 0f

            val cfg = Config.detector
            val a = Detector.analyze(px, ow, oh, cfg, own.x, own.y)
            own.update(a.own, ow, oh, cfg)
            val targets = Detector.buildTargets(a.enemies, ow, oh, cfg, own.x, own.y)
            val shown = tracker.update(targets, ow.toFloat() / oh, own.x, own.y)

            val ms = (System.nanoTime() - t0) / 1_000_000f
            procMs = if (procMs == 0f) ms else procMs * 0.8f + ms * 0.2f
            if (fpsStart == 0L) fpsStart = now
            fpsCount++
            if (now - fpsStart >= 1000) {
                fps = fpsCount * 1000f / (now - fpsStart)
                fpsStart = now
                fpsCount = 0
            }

            val lines = ArrayList<String>()
            lines.add("src ${img.width}x${img.height}  vd ${capW}x${capH}  step $step")
            lines.add("frames $frames  fps %.1f  proc %.1f ms".format(fps, procMs))
            lines.add(
                "bright $bright  nonblack %.0f%%  area %.0f%% x %.0f%%".format(nonBlackPct, boxW * 100, boxH * 100)
            )
            lines.add("soft-red %.1f%%  tinted ${if (a.tinted) "yes" else "no"}".format(a.softRedPct * 100))
            lines.add("red bars ${a.redBars}  boxes skipped ${a.boxesSkipped}  green ${a.greenBars}")
            lines.add(
                "enemies ${shown.size}  me ${if (own.found) "found" else "default"} (%.2f, %.2f)".format(own.x, own.y)
            )
            if (lastError.isNotEmpty()) lines.add("error: $lastError")

            val statusText: String
            val level: Int
            when {
                nonBlackPct < 3f -> { statusText = "Black frame: capture not working"; level = MenuController.LEVEL_WARN }
                boxW < 0.6f || boxH < 0.6f -> { statusText = "Capture looks cropped"; level = MenuController.LEVEL_WARN }
                a.tinted -> { statusText = "Tinted screen, ${shown.size} enemies"; level = MenuController.LEVEL_INFO }
                else -> { statusText = "Capture OK, ${shown.size} enemies"; level = MenuController.LEVEL_OK }
            }

            val debugLines = if (Config.debug) lines else emptyList()
            overlay?.post { overlay?.update(OverlayState(shown, own.x, own.y, own.found, debugLines)) }

            if (now - lastStats > 400) {
                lastStats = now
                lastReport = buildReport(lines, statusText)
                menu?.setStatus(statusText, level)
                if (Config.debug) menu?.setStats(lines.joinToString("\n"))
            }
            if (Config.debug && now - lastThumb > 600) {
                lastThumb = now
                menu?.setThumb(makeThumb(ow, oh, a))
            }
            if (saveRequested) {
                saveRequested = false
                menu?.setNote(saveFrame(ow, oh, a))
            }
        } catch (e: Exception) {
            lastError = "${e.javaClass.simpleName}: ${e.message ?: ""}"
            Log.e(TAG, "frame failed", e)
        } finally {
            img.close()
        }
    }

    private fun drawOutline(out: IntArray, tw: Int, th: Int, x0: Int, y0: Int, x1: Int, y1: Int, color: Int) {
        val l = x0.coerceIn(0, tw - 1)
        val r = x1.coerceIn(0, tw - 1)
        val t = y0.coerceIn(0, th - 1)
        val b = y1.coerceIn(0, th - 1)
        for (x in l..r) { out[t * tw + x] = color; out[b * tw + x] = color }
        for (y in t..b) { out[y * tw + l] = color; out[y * tw + r] = color }
    }

    private fun makeThumb(ow: Int, oh: Int, a: Analysis): Bitmap {
        val tw = 320
        val th = max(1, tw * oh / ow)
        val out = IntArray(tw * th)
        for (ty in 0 until th) {
            val sy = ty * oh / th
            for (tx in 0 until tw) {
                out[ty * tw + tx] = 0xFF000000.toInt() or px[sy * ow + tx * ow / tw]
            }
        }
        val sx = tw.toFloat() / ow
        val sy = th.toFloat() / oh
        for (b in a.enemies) {
            drawOutline(out, tw, th, (b.x0 * sx).toInt() - 1, (b.y0 * sy).toInt() - 1, (b.x1 * sx).toInt() + 1, (b.y1 * sy).toInt() + 1, 0xFF00E5FF.toInt())
        }
        a.own?.let { b ->
            drawOutline(out, tw, th, (b.x0 * sx).toInt() - 1, (b.y0 * sy).toInt() - 1, (b.x1 * sx).toInt() + 1, (b.y1 * sy).toInt() + 1, 0xFFFFEA00.toInt())
        }
        return Bitmap.createBitmap(out, tw, th, Bitmap.Config.ARGB_8888)
    }

    private fun saveFrame(ow: Int, oh: Int, a: Analysis): String {
        return try {
            val colors = IntArray(ow * oh)
            for (i in colors.indices) colors[i] = 0xFF000000.toInt() or px[i]
            val bmp = Bitmap.createBitmap(colors, ow, oh, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val cyan = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = 0xFF00E5FF.toInt() }
            val gold = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = 0xFFFFEA00.toInt() }
            for (b in a.enemies) canvas.drawRect(b.x0 - 2f, b.y0 - 2f, b.x1 + 3f, b.y1 + 3f, cyan)
            a.own?.let { b -> canvas.drawRect(b.x0 - 2f, b.y0 - 2f, b.x1 + 3f, b.y1 + 3f, gold) }

            val name = "overlaykit_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/OverlayKit")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: return "Save failed: no media entry"
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                "Saved: Pictures/OverlayKit/$name"
            } else {
                val f = File(getExternalFilesDir(null), name)
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                "Saved: ${f.absolutePath}"
            }
        } catch (e: Exception) {
            Log.e(TAG, "save failed", e)
            "Save failed: ${e.javaClass.simpleName}"
        }
    }

    private fun buildReport(lines: List<String>, status: String): String {
        val c = Config.detector
        return buildString {
            appendLine("Overlay Kit $VERSION  Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})  ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("status: $status")
            lines.forEach { appendLine(it) }
            appendLine("features: esp=${Config.esp} line=${Config.tracer} lowhp=${Config.lowHpMarker} warn=${Config.proximityWarning} radius=${Config.warnRadius} debug=${Config.debug}")
            appendLine("enemy bar color r${c.redRMin}-${c.redRMax} g${c.redGMin}-${c.redGMax} b${c.redBMin}-${c.redBMax}")
            appendLine("bar size w ${c.minW}-${c.maxW}  h ${c.minH}-${c.maxH}  aspect ${c.minAspect}-${c.maxAspect}  fill>=${c.minFill}  disc<=${c.discMax}")
        }
    }

    private fun copyReport() {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("Overlay Kit report", lastReport))
        menu?.setNote("Report copied. Paste it in the chat.")
    }

    override fun onDestroy() {
        released = true
        menu?.hide()
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        display?.release()
        reader?.close()
        projection?.stop()
        thread.quitSafely()
        super.onDestroy()
    }
}
