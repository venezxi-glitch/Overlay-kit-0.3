package app.overlaykit

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.roundToInt

class OverlayState(
    val targets: List<Target>,
    val ownX: Float,
    val ownY: Float,
    val ownFound: Boolean,
    val debugLines: List<String>,
)

class OverlayView(ctx: Context) : View(ctx) {

    @Volatile private var state = OverlayState(emptyList(), Config.DEFAULT_PLAYER_X, Config.DEFAULT_PLAYER_Y, false, emptyList())

    // Colors avoid pure red and green on purpose so the overlay is not read by its own capture.
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = 0xFF00E5FF.toInt()
    }
    private val lowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; color = 0xFFFFC107.toInt()
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f; color = 0xFFFFEA00.toInt()
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 26f; setShadowLayer(4f, 0f, 0f, 0xFF000000.toInt())
    }
    private val warnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 14f; color = 0xFFFF00FF.toInt()
    }
    private val dbgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 24f; textAlign = Paint.Align.RIGHT
        setShadowLayer(5f, 0f, 0f, 0xFF000000.toInt())
    }

    fun update(s: OverlayState) {
        state = s
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = state

        if (Config.debug) {
            val px = s.ownX * w
            val py = s.ownY * h
            c.drawLine(px - 16f, py, px + 16f, py, boxPaint)
            c.drawLine(px, py - 16f, px, py + 16f, boxPaint)
            c.drawText(if (s.ownFound) "me" else "me?", px + 20f, py - 8f, textPaint)
            var y = 64f
            for (line in s.debugLines) {
                c.drawText(line, w - 24f, y, dbgPaint)
                y += 28f
            }
        }

        val t = s.targets
        if (t.isEmpty()) return

        if (Config.esp) {
            for (e in t) {
                val low = Config.lowHpMarker && e.hp < LOW_HP
                c.drawRect(e.l * w, e.t * h, e.r * w, e.b * h, if (low) lowPaint else boxPaint)
                c.drawText("%d%%  %.2f".format((e.hp * 100).roundToInt(), e.dist), e.l * w, e.b * h + 28f, textPaint)
            }
        } else if (Config.lowHpMarker) {
            for (e in t) {
                if (e.hp < LOW_HP) c.drawRect(e.l * w, e.t * h, e.r * w, e.b * h, lowPaint)
            }
        }
        if (Config.tracer) {
            val n = t[0]
            c.drawLine(s.ownX * w, s.ownY * h, (n.l + n.r) / 2f * w, (n.t + n.b) / 2f * h, linePaint)
        }
        if (Config.proximityWarning && t[0].dist < Config.warnRadius) {
            c.drawRect(7f, 7f, w - 7f, h - 7f, warnPaint)
        }
    }

    private companion object {
        const val LOW_HP = 0.4f
    }
}
