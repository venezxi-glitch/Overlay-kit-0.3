package app.overlaykit

import kotlin.math.hypot

/** Keeps boxes steady: smooths movement, hides one-frame false hits, and bridges short gaps. */
class Tracker {
    private class Track(var l: Float, var t: Float, var r: Float, var b: Float, var hp: Float) {
        var seen = 1
        var missed = 0
    }

    private val tracks = ArrayList<Track>()

    fun reset() = tracks.clear()

    fun update(dets: List<Target>, aspect: Float, ownX: Float, ownY: Float): List<Target> {
        val used = BooleanArray(dets.size)
        for (tr in tracks) {
            var best = -1
            var bestD = MATCH_DIST
            for (i in dets.indices) {
                if (used[i]) continue
                val d = dets[i]
                val dx = ((tr.l + tr.r) / 2f - (d.l + d.r) / 2f) * aspect
                val dy = (tr.t + tr.b) / 2f - (d.t + d.b) / 2f
                val dist = hypot(dx, dy)
                if (dist < bestD) { bestD = dist; best = i }
            }
            if (best >= 0) {
                used[best] = true
                val d = dets[best]
                tr.l += (d.l - tr.l) * ALPHA
                tr.t += (d.t - tr.t) * ALPHA
                tr.r += (d.r - tr.r) * ALPHA
                tr.b += (d.b - tr.b) * ALPHA
                tr.hp += (d.hp - tr.hp) * ALPHA
                tr.seen++
                tr.missed = 0
            } else {
                tr.missed++
            }
        }
        tracks.removeAll { it.missed > MAX_MISSED }
        for (i in dets.indices) {
            if (!used[i] && tracks.size < MAX_TRACKS) {
                val d = dets[i]
                tracks.add(Track(d.l, d.t, d.r, d.b, d.hp))
            }
        }
        return tracks
            .filter { it.seen >= MIN_SEEN && it.missed <= SHOW_MISSED }
            .map { Target(it.l, it.t, it.r, it.b, Detector.distance(it.l, it.t, it.r, it.b, aspect, ownX, ownY), it.hp) }
            .sortedBy { it.dist }
    }

    private companion object {
        const val ALPHA = 0.6f
        const val MATCH_DIST = 0.08f
        const val MIN_SEEN = 2
        const val MAX_MISSED = 4
        const val SHOW_MISSED = 2
        const val MAX_TRACKS = 32
    }
}

/** Follows the player's own position, found from the own (green) health bar. */
class OwnTracker {
    var x = Config.DEFAULT_PLAYER_X
        private set
    var y = Config.DEFAULT_PLAYER_Y
        private set
    var found = false
        private set
    private var miss = 0

    fun reset() {
        x = Config.DEFAULT_PLAYER_X
        y = Config.DEFAULT_PLAYER_Y
        found = false
        miss = 0
    }

    fun update(bar: Bar?, w: Int, h: Int, c: DetectorConfig) {
        if (bar != null) {
            val tx = bar.cx / w
            val ty = (bar.y1 + c.unitCenter * c.fullBarW * h) / h
            if (!found) { x = tx; y = ty } else { x += (tx - x) * 0.5f; y += (ty - y) * 0.5f }
            found = true
            miss = 0
        } else if (found) {
            miss++
            if (miss > MAX_MISS) reset()
        }
    }

    private companion object {
        const val MAX_MISS = 45
    }
}
