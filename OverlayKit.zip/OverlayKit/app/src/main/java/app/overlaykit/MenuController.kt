package app.overlaykit

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min

class MenuController(
    base: Context,
    private val wm: WindowManager,
    private val onChanged: () -> Unit,
    private val onStop: () -> Unit,
    private val onCopy: () -> Unit,
    private val onSave: () -> Unit,
) {
    companion object {
        const val LEVEL_OK = 0
        const val LEVEL_WARN = 1
        const val LEVEL_INFO = 2
    }

    private val ctx = ContextThemeWrapper(base, android.R.style.Theme_DeviceDefault)
    private val accent = 0xFF8B7CFF.toInt()
    private val muted = 0xFF8F96AD.toInt()
    private val root = LinearLayout(ctx)
    private val scroll = ScrollView(ctx)
    private val panel = LinearLayout(ctx)
    private val statusText = TextView(ctx)
    private val hintText = TextView(ctx)
    private val debugBlock = LinearLayout(ctx)
    private val statsText = TextView(ctx)
    private val noteText = TextView(ctx)
    private val thumb = ImageView(ctx)
    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dp(8); y = dp(60)
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
        if (strokeColor != 0) setStroke(dp(1), strokeColor)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun section(text: String) = label(text, 11f, accent, true).apply {
        letterSpacing = 0.12f
        setPadding(0, dp(14), 0, dp(2))
    }

    private fun divider() = View(ctx).apply {
        setBackgroundColor(0x1FFFFFFF)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
    }

    private fun switchRow(title: String, desc: String, initial: Boolean, set: (Boolean) -> Unit): View {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, 14f, Color.WHITE))
        col.addView(label(desc, 11f, muted))
        val checked = intArrayOf(android.R.attr.state_checked)
        val sw = Switch(ctx).apply {
            isChecked = initial
            thumbTintList = ColorStateList(arrayOf(checked, intArrayOf()), intArrayOf(accent, 0xFFB5BBD0.toInt()))
            trackTintList = ColorStateList(arrayOf(checked, intArrayOf()), intArrayOf(0x778B7CFF, 0x33FFFFFF))
            setOnCheckedChangeListener { _, v -> set(v); onChanged(); updateHint() }
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(sw)
        return row
    }

    private fun button(text: String, action: () -> Unit) = Button(ctx).apply {
        this.text = text; setTextColor(Color.WHITE); isAllCaps = false; textSize = 13f
        background = rounded(0x338B7CFF, 12)
        minHeight = 0; minimumHeight = 0
        setPadding(dp(8), dp(9), dp(8), dp(9))
        setOnClickListener { action() }
    }

    private fun fitPanel() {
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(dp(260), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
        )
        val dm = ctx.resources.displayMetrics
        val cap = (min(dm.widthPixels, dm.heightPixels) * 0.72f).toInt()
        val p = scroll.layoutParams
        p.height = min(panel.measuredHeight, cap)
        scroll.layoutParams = p
        if (root.isAttachedToWindow) wm.updateViewLayout(root, lp)
    }

    private fun updateHint() {
        val anyOn = Config.esp || Config.tracer || Config.lowHpMarker || Config.proximityWarning
        hintText.visibility = if (anyOn) View.GONE else View.VISIBLE
    }

    init {
        root.orientation = LinearLayout.VERTICAL

        val bubble = TextView(ctx).apply {
            text = "\u2630"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        }

        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(14), dp(16), dp(14))

        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("Overlay Kit", 18f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(label("v0.3", 11f, muted))
        panel.addView(header)

        statusText.apply {
            text = "\u25CF Waiting for frames"; textSize = 12f; setTextColor(accent)
            background = rounded(0x1FFFFFFF, 10)
            setPadding(dp(10), dp(5), dp(10), dp(5))
        }
        panel.addView(statusText, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        hintText.apply {
            text = "All features are off. Switch on what you need."
            textSize = 11f; setTextColor(muted); setPadding(0, dp(8), 0, 0)
        }
        panel.addView(hintText)

        panel.addView(section("VISUALS"))
        panel.addView(switchRow("ESP boxes", "Box, health % and distance on enemies", Config.esp) { Config.esp = it })
        panel.addView(divider())
        panel.addView(switchRow("Line to nearest", "Line from you to the closest enemy", Config.tracer) { Config.tracer = it })
        panel.addView(divider())
        panel.addView(switchRow("Low HP marker", "Gold box when an enemy is under 40%", Config.lowHpMarker) { Config.lowHpMarker = it })

        panel.addView(section("ALERTS"))
        panel.addView(switchRow("Proximity warning", "Pink screen border when close", Config.proximityWarning) { Config.proximityWarning = it })
        val radiusLabel = label("Warning radius: %.2f".format(Config.warnRadius), 12f, muted).apply { setPadding(0, dp(6), 0, 0) }
        val radius = SeekBar(ctx).apply {
            max = 50; progress = (Config.warnRadius * 100).toInt()
            progressTintList = ColorStateList.valueOf(accent)
            thumbTintList = ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    Config.warnRadius = p / 100f
                    radiusLabel.text = "Warning radius: %.2f".format(Config.warnRadius)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { onChanged() }
            })
        }
        panel.addView(radiusLabel)
        panel.addView(radius)

        panel.addView(section("DEBUG"))
        panel.addView(switchRow("Debug info", "Live capture preview and numbers", Config.debug) {
            Config.debug = it
            debugBlock.visibility = if (it) View.VISIBLE else View.GONE
            fitPanel()
        })

        debugBlock.orientation = LinearLayout.VERTICAL
        statsText.apply {
            setTextColor(0xFFB8C0D8.toInt()); textSize = 10.5f; typeface = Typeface.MONOSPACE
            setPadding(0, dp(6), 0, dp(6))
        }
        thumb.apply {
            adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }
        val buttons = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(button("Copy report") { onCopy() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) })
        buttons.addView(button("Save frame") { onSave() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(4) })
        noteText.apply { textSize = 11f; setTextColor(accent); setPadding(0, dp(6), 0, 0) }
        debugBlock.addView(statsText)
        debugBlock.addView(thumb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        debugBlock.addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        debugBlock.addView(noteText)
        debugBlock.visibility = if (Config.debug) View.VISIBLE else View.GONE
        panel.addView(debugBlock)

        val stop = button("Stop and close") { onStop() }
        panel.addView(stop, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) })

        scroll.background = rounded(0xF2121420.toInt(), 18, 0x33FFFFFF)
        scroll.visibility = View.GONE
        scroll.addView(panel, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(bubble)
        root.addView(scroll, LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        updateHint()

        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx; val dy = e.rawY - sy
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                            wm.updateViewLayout(root, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        if (scroll.visibility == View.VISIBLE) {
                            scroll.visibility = View.GONE
                        } else {
                            fitPanel()
                            scroll.visibility = View.VISIBLE
                        }
                        wm.updateViewLayout(root, lp)
                    }
                }
                return true
            }
        })
    }

    fun show() = wm.addView(root, lp)

    fun hide() {
        try { wm.removeView(root) } catch (_: Exception) {}
    }

    fun setStatus(text: String, level: Int) {
        val color = when (level) {
            LEVEL_OK -> 0xFF00C878.toInt()
            LEVEL_WARN -> 0xFFFFB020.toInt()
            else -> accent
        }
        statusText.post {
            statusText.text = "\u25CF $text"
            statusText.setTextColor(color)
        }
    }

    fun setStats(s: String) {
        statsText.post { statsText.text = s }
    }

    fun setThumb(b: Bitmap) {
        thumb.post { thumb.setImageBitmap(b) }
    }

    fun setNote(s: String) {
        noteText.post { noteText.text = s }
    }
}
