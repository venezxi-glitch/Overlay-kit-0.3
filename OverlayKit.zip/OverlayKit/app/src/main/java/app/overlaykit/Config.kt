package app.overlaykit

import android.content.Context

object Config {
    // Every feature starts switched off.
    @Volatile var esp = false
    @Volatile var tracer = false
    @Volatile var lowHpMarker = false
    @Volatile var proximityWarning = false
    @Volatile var debug = false
    @Volatile var warnRadius = 0.25f // in screen heights

    // Used until the own health bar is found on screen (normalized 0..1).
    const val DEFAULT_PLAYER_X = 0.5f
    const val DEFAULT_PLAYER_Y = 0.5f

    @Volatile var detector = DetectorConfig()

    // New file name on purpose, so older saved settings do not switch features on.
    private const val FILE = "overlaykit_v3"

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        esp = p.getBoolean("esp", false)
        tracer = p.getBoolean("tracer", false)
        lowHpMarker = p.getBoolean("lowhp", false)
        proximityWarning = p.getBoolean("proximity", false)
        debug = p.getBoolean("debug", false)
        warnRadius = p.getFloat("warnRadius", 0.25f).coerceIn(0f, 0.5f)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("esp", esp)
            .putBoolean("tracer", tracer)
            .putBoolean("lowhp", lowHpMarker)
            .putBoolean("proximity", proximityWarning)
            .putBoolean("debug", debug)
            .putFloat("warnRadius", warnRadius)
            .apply()
    }
}
